**UNIVERSIDAD MARIANO GÁLVES DE GUATEMALA CENTRO UNIVERSITARIO    DE MAZATENANGO FACULTAD DE INGENIERIA EN SISTEMAS**

![Universidad Mariano Gálvez de Guatemala - UMG](logoUmg.png)

**MANUAL DE USUARIO**

Software de validación de vacunación para la vacuna del covid-19

**AUTOR**

David Ezequiel López Mendizábal

3090-22-9604

**DOCENTE**

Miguel Ángel Lemus pineda.

**GUATEMALA. S. S, 8 DE JUNIO 2024**

**INTRODUCCIÒN**

Este manual tiene como objetivo demostrar la utilidad y las funcionalidades que ofrece el software de Validador de vacunación covid-19 donde su objetivo fundamental se centra en poder visualizar los datos de vacunación que se realizaron en el año 2019 y de igual manera ejecutar las funciones básicas como mostrar los datos insertados, insertar datos por archivos internos del Sistema, como la búsqueda, encriptación, visualización de datos por gráfica y registro de datos buscados por archivos, arboles Binarios y arboles AVL.

Dentro del manual de usuario encontrara una estructura sencilla y detallada, hasta poder dominar el software adecuadamente, entre estas secciones se encuentran las funcionalidades de instalación, requerimientos y funcionalidades de los árboles. De ante mano agradecemos la confianza depositada en nosotros y nos comprometemos a que el software y el manual estén desarrollados adecuadamente. Para que pueda verificar y registrar sus datos en el validador de vacunación covid-19.

**ALCANCE DEL MANUAL**

Poder demostrar y ofrecerles a las personas de algún área de la tecnología o del área del centro de salud como a cualquier civil que puedan registrarse o validar si sus datos se encuentran en el Software de Validador de vacunación covid-19.

**PROPÓSITO DEL MANUAL**

Informar y demostrar por medio de imágenes y pasos a los usuarios que desean utilizar dicho Software donde se explica los procedimientos para navegar o interactuar dentro del programa con sus funciones. Donde podrán registrar, visualizar un árbol Binario y AVL en una gráfica y encriptar y desencriptar los datos ingresados como la manipulación y almacenamiento de datos en archivos de texto para datos de usos externos.

**INSTALACIÒN**

El propósito del software es poder que tener la funcionalidad de registrarse o visualizar datos pasados sobre el covid-19 al igual poder interactuar con las funcionalidades de encripta miento como otras.

**Requerimientos del Sistema**

Hardware Software (SO compatible, versiones de librerías, etc.)

**Instrucciones de descarga**

- Ingresar y buscar en un navegador web la pagina de GitHub 
- Desde de un repositorio de GitHub instalar el proyecto.

**Proceso de instalación**

- Dirigirse al perfil del nombre del autor e irse a la apartado de repositorios.
- Verificar que haya un repositorio público y poder descargarlo.
- Descomprimirlo en el sistema.
- Abrirlo en el IDE de apache NetBeans.
- Realizar su ejecución.

**GUÍA DE USUARIO**

**Seleccionar Archivo y cargarlo.**

Escoger el archivo en el menú que se encuentra en la parte superior de lado izquierdo y cargar el archivo al Árbol Binario u AVL.

![Interfaz de usuario gráfica, Texto, Aplicación, Correo electrónico Descripción generada automáticamente](menuBar.png)

![Interfaz de usuario gráfica, Texto, Aplicación, Correo electrónico Descripción generada automáticamente](selecArch.png)

Buscar el archivo de texto donde están los vacunas del covid-19 y seleccionarlo.

Escribir cuantas Líneas desea del archivo de texto, que se carguen en el árbol Binario u AVL.

![Interfaz de usuario gráfica Descripción generada automáticamente](ventanas.png)

**Insertar Datos en el Árbol**

![Interfaz de usuario gráfica, Texto, Aplicación, Word Descripción generada automáticamente](agregarDatos.png)

Seleccionamos la ventana del árbol donde cargamos el archivo y podremos observar que en la parte de abajo hay un botón de agregar.

Ingresamos datos en la cajita de texto presionamos el botón agregar y se carga, de igual manera podemos visualizar los datos que cargamos del archivo.

![Interfaz de usuario gráfica, Texto, Aplicación Descripción generada automáticamente](datosInscritos.png)

![Interfaz de usuario gráfica Descripción generada automáticamente](nodoEncontrado.png)

Al presionar el botón Inorden podemos visualizar que el nuevo dato que se agregó se encuentra ya cargado en el Árbol.

**Buscar Datos en el árbol**

Cundo se desea buscar un nodo podemos ingresar el dpi de la persona que deseamos buscar en el Árbol y darle en el botón de buscar lo cual se mostrara en el txtArea de a lado. Especificando el valor encontrado.

![Interfaz de usuario gráfica](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.011.png)

Al buscar el Nodo se mostrar el nodo encontrado, cuando se encuentre ese nodo, se observará que se habilitará el botón de actualizar para que pueda modificar el nodo buscado y de igual manera grabarlo en una archivo de txt, más adelante se especificará.

**Modificar Datos del Árbol**

![Interfaz de usuario gráfica, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.012.png)

Al habilitarse el botón de actualizar podemos presionar el botón de actualizar el cual nos dirigirá a una ventana nueva.

Al presionar el botón de actualizar se abrirá la ventana donde ingresaremos los datos faltantes del nodo que buscamos anteriormente para poder modificarlo. Al darle al botón de atrás no dirigirá al menú y al darle en el botón Inorden podremos verificar que el nodo que se buscó en el árbol se modificó. Teniendo en cuenta que es temporal hay que guardarlo en archivo de texto el cual más adelante se especifica mejor.

![Una captura de pantalla de una computadora Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.013.png)

![Texto, Carta Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.014.png)

**Grabar datos en el archivo y Cargar Datos del archivo en el BBT Y AVL**

**Grabar en el archivo**

Al darle clic en el botón de Grabar Archivo se está guardando el nodo que se modificó anteriormente, por lo tanto, los datos modificados se guardarán en un archivo de texto con el nombre del árbol que se escogió. Donde solo los datos modificados se guardarán al igual no pasa nada al no presionar el botón Grabar Archivos solo se guardarán temporalmente.

![Interfaz de usuario gráfica](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.015.png)

**Cargar el archivo en el árbol BBT Y AVL**

Al darle clic en el botón de Cargar Archivo se está cargando los datos del archivo que almacena los datos o nodos modificados lo cual se observara que mostrara en pantalla que ya se cargaron y al verificar en el con el botón Inorden u otro se observaran los datos del archivo ya cargados.

![Interfaz de usuario gráfica, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.016.png)

![Interfaz de usuario gráfica, Texto, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.017.png)

**Eliminar Datos del Árbol**

El procedimiento de eliminación es el mismo solamente que en vez de solo buscar se eliminara el nodo al presionar el botón de eliminar.

![Interfaz de usuario gráfica, Texto, Aplicación, Word Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.018.png)

Al presionar el botón de eliminar arrojara en pantalla que el nodo ha sido eliminado por lo tanto se puede visualizar dando clic en el botón de Inorden para verificar si se eliminó en el árbol.

![Interfaz de usuario gráfica, Texto, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.019.png)

![Texto Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.020.png)

**Recorrer Datos del Árbol**

Al presionar el botón Inorden, Preorden y PostOrden se puede verificar que el contenido del árbol se muestra en diferente orden teniendo en cuenta que el Inorden muestra los datos de menor a mayor parecido al de PostOrden, pero no son igual y el de Preorden de manera como se insertó.

![Interfaz de usuario gráfica, Texto Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.021.png)

**Inorden**

![Interfaz de usuario gráfica, Texto, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.022.png)

**Preorden**

![Interfaz de usuario gráfica, Texto, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.023.png)

**Postorden**

**Encriptar Datos del Árbol y del archivo**

![Interfaz de usuario gráfica, Texto, Aplicación Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.024.png)

Al presionar el botón de Encriptar se encriptará los datos del Árbol y los datos del archivo. Al mismo tiempo lo cual se puede visualizar en pantalla cuando se recorren los datos de nuevo, pero ya encriptados.

![Interfaz de usuario gráfica Descripción generada automáticamente con confianza baja](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.025.png)

![Imagen que contiene Gráfico Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.026.png)

**Desencriptar Datos del Árbol y del archivo**

![Interfaz de usuario gráfica, Texto, Aplicación, Word](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.027.png)

El mismo procedimiento con el método de desencriptar y visualizarlo con uno de los tres recorridos para verificar si los desencripta, tener en cuenta que al no desencriptar y a ver encriptado todo antes se quedara encriptado, pero se puede ejecutar el programa para solo desencriptarlo.

![Imagen que contiene Interfaz de usuario gráfica Descripción generada automáticamente](Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.028.png)

**Visualización del árbol Imagen**

Para visualizar el árbol ya sea Binario u AVL se debe de presionar el botón de “BBT IMG” O “AVL IMG”, el cual mostrara el árbol Binario y el de AVL, verificando que uno no esta balanceado y el otro sí.

**BBT IMG**

![Imagen que contiene Diagrama](ImgBBT.png)

**AVL IMG**

![Diagrama, Esquemático Descripción generada automáticamente](ImgAVL.png)

[Interfaz de usuario gráfica Descripción generada automáticamente]: Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.004.png
[Interfaz de usuario gráfica Descripción generada automáticamente]: Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.005.png
[Interfaz de usuario gráfica]: Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.009.png
[Interfaz de usuario gráfica]: Aspose.Words.fa9964e5-378e-424c-bdea-069b9b7c74d7.014.png
