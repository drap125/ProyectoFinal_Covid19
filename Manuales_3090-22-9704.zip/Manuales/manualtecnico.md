<!-- PORTADA -->
# UNIVERSIDAD MARIANO GÁLVES DE GUATEMALA
## CENTRO UNIVERSITARIO DE MAZATENANGO
## FACULTAD DE INGENIERÍA EN SISTEMAS

---

# MANUAL TÉCNICO
## Software de validación de vacunación para la vacuna del COVID-19

---

### AUTOR
**David Ezequiel López Mendizábal**
- 3090-22-9604

### DOCENTE
**Miguel Ángel Lemus Pineda**

---

GUATEMALA. S. S, 8 DE JUNIO 2024

---
---
---
---


# INTRODUCCIÒN
Este manual tiene como objetivo demostrar la utilidad y las funcionalidades que ofrece el software de Validador de vacunación covid-19  donde su objetivo fundamental se centra en poder visualizar los datos de vacunación que se realizaron en el año 2019 y de igual manera ejecutar las funciones básicas como mostrar los datos insertados , insertar datos por archivos internos del Sistema, como la búsqueda, encriptación , visualización de datos por gráfica  y registro de datos buscados por archivos, arboles Binarios y arboles AVL. 


---
---

## ESTRUCTURA DEL CODIGO
leer archivo del árbol binario y avl
La parte principal de los requisitos del proyecto se encuentra en la clase de LeerArchivo, el cual contiene dos métodos llamados leerArch y leerArchAVL   y la clase MenuPrincipal que contiene dos botones para poder seleccionar el archivo y pasar como parámetro el tipo de árbol y la dirección de ese archivo para manipularlo, llamado file. 

![visual studio code logo](cargarArchivo.png)


El código es redundante por lo tanto el siguiente método también se aplica al Arbol AVL. El método recibe un tipo de árbol y un objeto de tipo File el cual es la dirección y la manipulación de datos del archivo que se selecciono y va leyendo el archivo línea por línea y separado por tabulación en el nombre y en el dpi, para luego insertarlo en un árbol binario o de balance cada valor que vaya leyendo del archivo asta que el usuario indique cuando desea leer y se cierra.

![visual studio code logo](metArch.png)

---
---
---
## ARBOL BINARIO 
Clase de nodo binario

Se compone de un constructor donde hay nuevos datos contando el dpi y el nombre, al igual los 7 datos nuevos contienen sus propios get y set.

![visual studio code logo](nodoBBT.png)

## Insertar datos en el nodo
Un método que recibe como parámetro todos los datos para insertar al Arbol Binario. Verificando si existe un nodo en el caso de que sea NULL insertara el primero. Si en el caso de que ya hay nodos entrara al while con los nodos auxiliar y padre verificando si el dpi es mayor o menor para luego ser desplazado a la izquierda o derecha donde el nodo auxiliar se encargara de recorrer el árbol y el padre de desplazar el nuevo nodo, verificando si es mayor o menor.

![visual studio code logo](agregarBBT.png)

## Buscar nodo del árbol binario
Un método de tipo NodoArbol que recibe como parámetro un valor de tipo Long y la creación de un NodoArbol llamado auxiliar para ir recorriendo con el while. Si el dato del aux es diferente del valor a buscar se necesitará verificar si el dato a buscar es menor al aux.dato de serlo se desplazará a la izquierda asta encontrarlo y se terminada la condición del while, el mismo procedimiento es de lado derecho. Al encontrar el valor retornará el nodo encontrado y lo guardará en un nodoEncontrado  que servirá para modificar el dato que se buscó.
![visual studio code logo](buscarBBT.png)

## Modificar nodo del árbol
Retomando la descripción anterior se usa el mismo Nodo llamado nodoEncontrado para agregarles los valores faltantes al nodo que se buscó en el método buscar, los datos que se pasa ´por parámetro en el método modificar son de una Clase JFrame donde se ingresa los datos por txtField. El código lo veremos en más adelante en el código de la interfaz.
![visual studio code logo](modificarBBT.png)

## Recorrer nodos del Arbol Binario
El proceso de este código consiste en recorrer el árbol binario en un orden determinado, este tipo de orden tiene variedades conocidos como Inorden, Preorden, Postorden, los cuales se encargan ir recorriendo el árbol, pero de manera recursiva el método recibe dos parámetros de tipo NodoArbol y uno de tipo objeto StringBuilder el cual sirve para ir concatenando cada dato que el método vaya recorriendo y lo almacene y retorne a la interfaz donde se llama. 
![visual studio code logo](recrorridos.png)

## Eliminar nodo del árbol  Binario

El siguiente código tiene un método de eliminación el cual esta estructurado de varias opciones para realizar la eliminación del nodo correctamente. Los casos que utiliza comienzan entre lo básico asta remplazar el nodo que tenga dos hijos. El código se estructura por la primera parte donde busca el nodo a eliminar retornando el nodo auxiliar, el nodo auxiliar HijoDerecho u HijoIzquierdo donde empieza verificar dependiendo el hijo que retorno si el nodo a eliminar no tiene hijos, del ser el caso así, solamente eliminaría ese nodo = NULL. 

El procedimiento del método ObtenerNodoReemplazo(). Se encarga de buscar el nodo más a la izquierda en el sub-árbol derecho y hace el remplazo del nodo, de ser el caso que el nodo no se el hijo derecho exacto a eliminar, el método se ajusta entre conexión para que el nodo de remplazo ocupe el nodo a eliminar. En Simples palabras se encarga de recorrer cada condición asta dar con el que se desea eliminar.
![visual studio code logo](obtenerRemp.png)

---
Los metodos basicos del arbol AVL son los mismos por lo tanto se describiran los más imporantes como factor de equilibrio, eliminacion y rotaciones
--

## ARBOL AVL
### METODO ELIMINAR AVL

La función eliminarNodo elimina un nodo del árbol AVL según el valor del dpi. Esta función de eliminación de  árboles binarios de búsqueda. tiene entendido que si el  nodo a eliminar tiene dos hijos, se reemplaza su valor con el valor del nodo mínimo del sub-árbol derecho o el máximo del subárbol izquierdo para que  luego se elimina ese nodo mínimo (máximo).

```
public NodoAVL eliminarNodo(NodoAVL raiz, long dpi) {
    if (raiz == null)
        return raiz;

    if (dpi < raiz.dpi)
        raiz.hijoIzquierdo = eliminarNodo(raiz.hijoIzquierdo, dpi);
    else if (dpi > raiz.dpi)
        raiz.hijoDerecho = eliminarNodo(raiz.hijoDerecho, dpi);
    else {
        if (raiz.hijoIzquierdo == null || raiz.hijoDerecho == null) {
            NodoAVL temp = null;
            if (temp == raiz.hijoIzquierdo)
                temp = raiz.hijoDerecho;
            else
                temp = raiz.hijoIzquierdo;

            if (temp == null) {
                temp = raiz;
                raiz = null;
            } else
                raiz = temp;
        } else {
            NodoAVL temp = obtenerNodoMinimo(raiz.hijoDerecho);
            raiz.dpi = temp.dpi;
            raiz.hijoDerecho = eliminarNodo(raiz.hijoDerecho, temp.dpi);
        }
    }

    if (raiz == null)
        return raiz;

    // Actualizar la altura
    raiz.fe = Math.max(obtenerFE(raiz.hijoIzquierdo), obtenerFE(raiz.hijoDerecho)) + 1;

    // Verificar el balance y realizar rotaciones si es necesario
    int balance = obtenerFE(raiz.hijoIzquierdo) - obtenerFE(raiz.hijoDerecho);
    if (balance > 1 && obtenerFE(raiz.hijoIzquierdo.hijoIzquierdo) - obtenerFE(raiz.hijoIzquierdo.hijoDerecho) >= 0)
        return rotacionIzquierda(raiz);

    if (balance > 1 && obtenerFE(raiz.hijoIzquierdo.hijoIzquierdo) - obtenerFE(raiz.hijoIzquierdo.hijoDerecho) < 0) {
        raiz.hijoIzquierdo = rotacionDerecha(raiz.hijoIzquierdo);
        return rotacionIzquierda(raiz);
    }

    if (balance < -1 && obtenerFE(raiz.hijoDerecho.hijoDerecho) - obtenerFE(raiz.hijoDerecho.hijoIzquierdo) >= 0)
        return rotacionDerecha(raiz);

    if (balance < -1 && obtenerFE(raiz.hijoDerecho.hijoDerecho) - obtenerFE(raiz.hijoDerecho.hijoIzquierdo) < 0) {
        raiz.hijoDerecho = rotacionIzquierda(raiz.hijoDerecho);
        return rotacionDerecha(raiz);
    }
    return raiz;
}


// Método para obtener el nodo mínimo (el más a la izquierda)
public NodoAVL obtenerNodoMinimo(NodoAVL nodo) {
    NodoAVL actual = nodo;
    while (actual.hijoIzquierdo != null)
        actual = actual.hijoIzquierdo;
    return actual;
}
   
    
// Buscar Nodo
     public NodoAVL buscar(long dpi, NodoAVL r) {
        if (raiz == null) {
            nodoEncontrado = null;
            return null;
        } else if (r.dpi == dpi) {
            nodoEncontrado = r; // Guardar el nodo encontrado
            return r;
        } else if (r.dpi < dpi) {
            return buscar(dpi, r.hijoDerecho);
        } else {
            return buscar(dpi, r.hijoIzquierdo);
        }
    }
    
    public void modificar(String departamento, String municipio, String cantidad, String primerFvacuna, String segundaFvacuna, String tercerarFvacuna, String lugarVacunacion){
        nodoEncontrado.setDepartamento(departamento);
        nodoEncontrado.setMunicipio(municipio);
        nodoEncontrado.setCantidad(cantidad);
        nodoEncontrado.setPrimerFvacuna(primerFvacuna);
        nodoEncontrado.setSegundaFvacuna(segundaFvacuna); 
        nodoEncontrado.setTercerarFvacuna(tercerarFvacuna);
        nodoEncontrado.setLugarVacunacion(lugarVacunacion);
    }
    
  public String obtenerCodigoGraphviz() {
    StringBuilder texto = new StringBuilder();
    texto.append("digraph G {\n");
    texto.append("     node [shape = circle, style = filled, fillcolor = \"#EEEEE\", color = \"#EEEEE\", width = 0.5, height = 0.5];\n");
    texto.append("     edge [color = \"#31CEF0\"];\n\n");

    if (raiz != null) {
        texto.append(raiz.textoGraphviz());
    }
    texto.append("}\n");
    return texto.toString();
    }

```


## METODO DE FACTOR DE EQUILIBRIIO 
metodo para obtener el factor de equilibrio el cual obtenemos la medidad que indicssa la diferencia entre las alturas de los sub-arboles izq y dere de un nodo de una AVL

```
 public int obtenerFE(NodoAVL x){
        if(x == null){
            return -1;
        } else {
            return x.fe;
        }
    }
```

## ROTACIONES SIMPLES Y DOBLES

## Rotacion Izquierda
Se toma un nodo y se realiza una rotacion simple a la izquierda  almacena el hijo izquierdo y se lo asigna al hijo derecho de auxiliar asta que devuelve el nuevo nodo raiz del sub-arbol.

```
 public NodoAVL rotacionIzquierda(NodoAVL c){
        NodoAVL auxiliar = c.hijoIzquierdo;
        c.hijoIzquierdo = auxiliar.hijoDerecho;
        auxiliar.hijoDerecho = c;
        
        // Actualizar altura
        c.fe = Math.max(obtenerFE(c.hijoIzquierdo), obtenerFE(c.hijoDerecho)) + 1;
        auxiliar.fe = Math.max(obtenerFE(auxiliar.hijoIzquierdo), c.fe) + 1;
        
        return auxiliar;
    }
```

## Rotacion Derecha
Es similar a la rotacion simple izquierda pero realiza una rotacion simple a la derecha (lo inverso)

```
  public NodoAVL rotacionDerecha(NodoAVL c){
        NodoAVL auxiliar = c.hijoDerecho;
        c.hijoDerecho = auxiliar.hijoIzquierdo;
        auxiliar.hijoIzquierdo = c;
        
        // Actualizar altura
        c.fe = Math.max(obtenerFE(c.hijoIzquierdo), obtenerFE(c.hijoDerecho)) + 1;
        auxiliar.fe = Math.max(obtenerFE(auxiliar.hijoDerecho), c.fe) + 1;
        
        return auxiliar;
    }
```

## Rotacion doble izquierdo y derecho
Esta rotacion hace una doble rotacion a la izquierda cuando el arbol esta desvalanciado lo cual aplica una rotacion derecha al hijo izquierdo  y luego aplica una rotacion izquierda al nodo. en el caso del doble derecho es lo mismo solo que inverso asia la izquierdo


```
public NodoAVL rotacionDobleIzquierda(NodoAVL c){
        c.hijoIzquierdo = rotacionDerecha(c.hijoIzquierdo);
        return rotacionIzquierda(c);
    }
    
    public NodoAVL rotacionDobleDerecha(NodoAVL c){
        c.hijoDerecho = rotacionIzquierda(c.hijoDerecho);
        return rotacionDerecha(c);
    }
```


## Insertar AVL
Este metodo asegura que se inserte un nuevo nodo en el lugar correcto del arbol avl, en pocas palabras es el que mantiene la insercion de un nodo en el arbol y el equilibrio.
```
 public NodoAVL insertarAVL(NodoAVL nuevo, NodoAVL subAr){
        NodoAVL nuevoPadre = subAr;
        
        if(nuevo.dpi < subAr.dpi){
            if(subAr.hijoIzquierdo == null){
                subAr.hijoIzquierdo = nuevo;
            } else {
                subAr.hijoIzquierdo = insertarAVL(nuevo, subAr.hijoIzquierdo);
                
                // Verificar balance y aplicar rotaciones si es necesario
                if(obtenerFE(subAr.hijoIzquierdo) - obtenerFE(subAr.hijoDerecho) == 2){
                    if(nuevo.dpi < subAr.hijoIzquierdo.dpi){
                        nuevoPadre = rotacionIzquierda(subAr);
                    } else {
                        nuevoPadre = rotacionDobleIzquierda(subAr);
                    }
                }
            }
        } else if(nuevo.dpi > subAr.dpi){
            if(subAr.hijoDerecho == null){
                subAr.hijoDerecho = nuevo;
            } else {
                subAr.hijoDerecho = insertarAVL(nuevo, subAr.hijoDerecho);
                
                // Verificar balance y aplicar rotaciones si es necesario
                if(obtenerFE(subAr.hijoDerecho) - obtenerFE(subAr.hijoIzquierdo) == 2){
                    if(nuevo.dpi > subAr.hijoDerecho.dpi){
                        nuevoPadre = rotacionDerecha(subAr);
                    } else {
                        nuevoPadre = rotacionDobleDerecha(subAr);
                    }
                }
            }
        } else {
            System.out.println("Nodo duplicado");
        }
        
        // Actualizar la altura
        subAr.fe = Math.max(obtenerFE(subAr.hijoIzquierdo), obtenerFE(subAr.hijoDerecho)) + 1;
        
        return nuevoPadre;
    }
```



____

_____

# CLASS EncriptarArchivo
## Creacion del archivo EN EL ARBOL BBT Y AVL
Se crearon dos tipos de objetos File para la manipulacion de archivos al igual que un constructor que berifica si existe ese archivo o si no, en el caso de que no exista crea un archivo ya se BBT o AVL. Si ya existe solamente toma el valor del nodo  y lo pasa por parametro en el metodo crearArchivo() u crearArchivoAVL() 
donde crea un linea de tipo string y va escribiendo en el archivo cada dato que tiene el nodo que se paso por parametro. este es un ejemplo del arbolBinario pero existe el del AVL aparte solo es por reduccion de texto.

```
    private File miArchivoBBT;
    private File miArchivoAVL;
    
    public EncriptarArchivo() {
        miArchivoBBT = new File("archivoBBT.txt");
        miArchivoAVL = new File("archivoAVL.txt");
        
        try {
            if (!miArchivoBBT.exists()) {
                miArchivoBBT.createNewFile();
            }
            if (!miArchivoAVL.exists()) {
                miArchivoAVL.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public File getMiArchivoBBT() {
        return miArchivoBBT;
    }
    
    public File getMiArchivoAVL() {
        return miArchivoAVL;
    }
  
    
       public void crearArchivo(NodoArbol nodo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(miArchivoBBT, true))) {
            String linea = nodo.dato + "/" + nodo.nombre + "/" + nodo.departamento + "/" + nodo.municipio + "/" + nodo.cantidad + "/" + nodo.primerFvacuna + "/" + nodo.segundaFvacuna + "/" + nodo.tercerarFvacuna + "/" + nodo.lugarVacunacion;
            writer.write(linea);
            writer.newLine(); // Añadir nueva línea para cada entrada
            System.out.println("Datos inscritos en el archivo.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

```


## CARGAR ARCHIVO EN EL ARBOL BBT Y AVL 
Este metodo es un ejemplo de cargar Datos en un ARBOL AVL que tiene un archivo, a un que es similar al de BBT. Su funcionalidad consta en leer el archivo que esta en el proyecto y leer linea por linea para ir insertando los datos en un arbol BBT O AVL.


```
public void cargarAVL(ArbolAVL arbolitoAVL){
        try{
            FileReader archivo = new FileReader("archivoBBT.txt");
            BufferedReader lectura = new BufferedReader(archivo);
            
            String linea;
            
            while((linea = lectura.readLine()) != null){
            String[] fila = linea.split("/");
                if(fila.length == 9){
                             
                    long dpi = Long.parseLong(fila[0]);
                    arbolitoAVL.insertarNodo(dpi, fila[1], fila[2], fila[3], fila[4], fila[5], fila[6], fila[7], fila[8]);
              
                }
            }
            JOptionPane.showMessageDialog(null, "Inscripcción Correcta");
        }catch(IOException | NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Inscripcion Fallida");
            
        }
        
    }
    
```


## Encriptar datos del nodo y archivo
La encriptacion se compone de un metodo que pasa como paremetro un dato de tipo String el cual entra a varias condiciones donde se verifica si el datos es una letra ya se mayuscula o minuscula para encriptarlo, desplazandose 4 posiciones hacia adelante en el albafeto, de igual manera si es minuscula la letra. En el caso de que sea un numero su encriptacion es deplanzado el valor a encriptar 4 posiciones asia adelante.

```
 public static String encrip(String texto) {
    StringBuilder resultado = new StringBuilder();

    for (int i = 0; i < texto.length(); i++) {
        char caracter = texto.charAt(i);
        // Si el caracter es una letra, lo encriptamos
        if (Character.isLetter(caracter)) {
            // Si es una letra mayúscula, aplicamos el desplazamiento
            if (Character.isUpperCase(caracter)) {
                caracter = (char) ((caracter - 'A' + 4) % 26 + 'A');
            } else { // Si es una letra minúscula
                caracter = (char) ((caracter - 'a' + 4) % 26 + 'a');
            }
        } else if (Character.isDigit(caracter)) { // Si el caracter es un número, lo encriptamos
            // Aplicamos el desplazamiento para los números
            caracter = (char) ((caracter - '0' + 4) % 10 + '0');
        }
        resultado.append(caracter);
    }

    return resultado.toString();
}

```
El procedimiento de encriptar un nodo y un archivo es basicamente recibir un nodo y un archivo que no sea null y que no tenga datos vacios para poder ir cambiando los valores de todos los nodos guardando los datos desencriptar y en el archivo se crea un objeto de tipo path para obtener todo el contenido del archivo y manipularlo para pasarlo al metodo de encriptar.
```
 public static  void encriptarArchivo(File archivo) throws IOException {
        Path path = Paths.get(archivo.getAbsolutePath());
        String contenido = new String(Files.readAllBytes(path));
        String contenidoEncriptado = encrip(contenido);
        Files.write(path, contenidoEncriptado.getBytes());
    }
    

    public void encriptarTodos(NodoArbol nodo) {
        if (nodo != null) {
            nodo.dato =Long.parseLong(encrip(Long.toString(nodo.dato)));
            nodo.nombre = encrip(nodo.nombre);
            nodo.departamento = encrip(nodo.departamento);
            nodo.municipio = encrip(nodo.municipio);
            nodo.cantidad = encrip(nodo.cantidad);
            nodo.primerFvacuna = encrip(nodo.primerFvacuna);
            nodo.segundaFvacuna = encrip(nodo.segundaFvacuna);
            nodo.tercerarFvacuna = encrip(nodo.tercerarFvacuna);
            nodo.lugarVacunacion = encrip(nodo.lugarVacunacion);
            encriptarTodos(nodo.HijoIzquierdo);
            encriptarTodos(nodo.HijoDerecho);
        }
    }
```



 ## Desencriptar datos del nodo y archivo
El metodo de encriptacion cumple con la funcion inversa, donde desencripta los datos y verifica por condciones de if y distribuye el texto en un tipo char para iterar sobre el. 
```

public static String desincrip(String texto) {
    StringBuilder resultado = new StringBuilder();

    for (int i = 0; i < texto.length(); i++) {
        char caracter = texto.charAt(i);
        // Si el caracter es una letra, lo desencriptamos
        if (Character.isLetter(caracter)) {
            // Si es una letra mayúscula, aplicamos el desplazamiento inverso
            if (Character.isUpperCase(caracter)) {
                caracter = (char) ((caracter - 'A' - 4 + 26) % 26 + 'A');
            } else { // Si es una letra minúscula
                caracter = (char) ((caracter - 'a' - 4 + 26) % 26 + 'a');
            }
        } else if (Character.isDigit(caracter)) { // Si el caracter es un número, lo desencriptamos
            // Aplicamos el desplazamiento inverso para los números
            caracter = (char) ((caracter - '0' - 4 + 10) % 10 + '0');
        }
        resultado.append(caracter);
    }

    return resultado.toString();
}

```

El procedimiento de desencriptar un nodo y un archivo es basicamente recibir un nodo y un archivo que no sea null y que no tenga datos vacios para poder ir cambiando los valores de todos los nodos guardando los datos desencriptar y en el archivo se crea un objeto de tipo path para obtener todo el contenido del archivo y manipularlo para pasarlo al metodo de desencriptar.

```
   public void desencriptarTodos(NodoArbol nodo) {
        if (nodo != null) {
            
            nodo.dato = Long.parseLong(desincrip(Long.toString(nodo.dato)));
            nodo.nombre = desincrip(nodo.nombre);
            nodo.departamento = desincrip(nodo.departamento);
            nodo.municipio = desincrip(nodo.municipio);
            nodo.cantidad = desincrip(nodo.cantidad);
            nodo.primerFvacuna = desincrip(nodo.primerFvacuna);
            nodo.segundaFvacuna = desincrip(nodo.segundaFvacuna);
            nodo.tercerarFvacuna = desincrip(nodo.tercerarFvacuna);
            nodo.lugarVacunacion = desincrip(nodo.lugarVacunacion);
            desencriptarTodos(nodo.HijoIzquierdo);
            desencriptarTodos(nodo.HijoDerecho);
        }
    }

    public void desencriptarArchivo(File archivo) throws IOException {
        Path path = Paths.get(archivo.getAbsolutePath());
        String contenido = new String(Files.readAllBytes(path));
        String contenidoDesencriptado = desincrip(contenido);
        Files.write(path, contenidoDesencriptado.getBytes());
    } 
    
```


# INTERFACES

## Class menu PRINCIPAL  
### BOTONES DEL ARBOL BBT
Se encuentran los botones que dan la funcionalidad al arbol binario que son parte de la interfaz, como el de agregar los botenes de recorrido, buscar, eliminar, actualizar, IMG Graphiv, botones de encriptar, desencriptar y los de grabar y cargar. Estos simplemente acceden a los atributos del Arbol Binario como la raiz y sus metodos para que haya una conexion entre el metodo y el boton. Los botones que no se han mencionado es porque cumplen con la misma funcionalidad.
```
 
    private void agregarBBTActionPerformed(java.awt.event.ActionEvent evt) {                                           
        String var = txtBTT.getText();
        long dpi = Long.parseLong(var);
        arbolito.AgregarNodo(dpi, "", "", "", "", "", "", "", "");
        txtBTT.setText("");
    }                                          

    private void inOrdBBTActionPerformed(java.awt.event.ActionEvent evt) {                                         
        StringBuilder dat = new StringBuilder();
        txtArea1.setText("");
        if (arbolito != null && !arbolito.EstaVacio()) {
            arbolito.InOrden(arbolito.raiz, dat);
        }
        txtArea1.setText(dat.toString());
    }                                        

    private void preOrdBBTActionPerformed(java.awt.event.ActionEvent evt) {                                          
        StringBuilder dat = new StringBuilder();
        txtArea1.setText("");
        if (arbolito != null && !arbolito.EstaVacio()) {
            arbolito.PreOrden(arbolito.raiz, dat);
        }
        txtArea1.setText(dat.toString());
    }                                         

    private void postBBTActionPerformed(java.awt.event.ActionEvent evt) {                                        
        StringBuilder dat = new StringBuilder();
        txtArea1.setText("");
        if (arbolito != null && !arbolito.EstaVacio()) {
            arbolito.PostOrden(arbolito.raiz, dat);
        }
        txtArea1.setText(dat.toString());
    }                                       

    private void buscarBBTActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
        if (!arbolito.EstaVacio()) {
            String bsc = txtBTT.getText();
            long dpi = Long.parseLong(bsc);
            NodoArbol tmp;
            tmp = arbolito.BuscarNodo(dpi);
            txtBTT.setText("");
            if (tmp == null) {
                txtArea1.setText("El nodo buscado no se encuentra en el arbol" + "No_Encontrado");

            } else {
                String strDat = String.valueOf(dpi);
                txtArea1.setText("Nodo enncontrado, sus datos son: " + dpi);
                nodoEncontrado = tmp;
                actualizarBBT.setEnabled(true);
            }
        } else {
            txtArea1.setText("El arbol esta vacio");
        }
        
    }                                         

    
    private void eliminarBBTActionPerformed(java.awt.event.ActionEvent evt) {                                            
        String bsc = txtBTT.getText();
        long dpi = Long.parseLong(bsc);
        txtBTT.setText("");
        if (!arbolito.EstaVacio()) {
            if (arbolito.EliminarNodo(dpi) == false) {
                txtArea1.setText("Nodo no Encontrado");
            } else {
                txtArea1.setText("El Nodo Eliminado");
            }
        } else {
            txtArea1.setText("El Arbol esta vacio");
        }
    }                                           

    private void Graphviz_BBTActionPerformed(java.awt.event.ActionEvent evt) {                                             
    arbolito.dibujarGraphviz();
    String path = "arbl.png";
    
    // Verifica que la ruta sea correcta
    File file = new File(path);
    if (file.exists()) {
        ImageIcon ic = new ImageIcon(path);
        Image nw = ic.getImage().getScaledInstance(imgBBT.getWidth(), imgBBT.getHeight(), Image.SCALE_SMOOTH); 
        ImageIcon nc = new ImageIcon(nw);
        imgBBT.setIcon(nc);
    } else {
        System.out.println("La imagen no existe en la ruta especificada: " + path);
    }
    }                                            

    private void btnEncriptarActionPerformed(java.awt.event.ActionEvent evt) {                                             
        try {
            encrip.encriptarTodos(arbolito.raiz);
            encrip.encriptarArchivo(encrip.getMiArchivoBBT());
        } catch (IOException ex) {
            Logger.getLogger(MenuPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }                                            

```

### BOTONES DEL ARBOL AVL
Los botones del Arbol AVL realizan el mismo procedimiento que los botones del binario a un que existe una diferencia entre los botones de buscar y elimminar. que seran mostrados a continuacion con la variedad de botones del avl:

``` 
    private void agregarAVLActionPerformed(java.awt.event.ActionEvent evt) {                                           
        String varAVL = txtAVL.getText();
        long dpi = Long.parseLong(varAVL);
        arbolitoAVL.insertarNodo(dpi,"", "", "", "", "", "", "", "");
        txtAVL.setText("");               
    }                                          

    private void btnBuscarAVLActionPerformed(java.awt.event.ActionEvent evt) {                                             
         if (!arbolitoAVL.estaVacioElArbol()) {
            String bsc = txtAVL.getText();
            long dpi = Long.parseLong(bsc);
            NodoAVL tmp;
            tmp = arbolitoAVL.buscar(dpi, arbolitoAVL.raiz);
            txtAVL.setText("");
            if (tmp == null) {
                txtAreAVL.setText("El nodo buscado no se encuentra**");

            } else {
                String strDat = String.valueOf(dpi);
                txtAreAVL.setText("Nodo enncontrado sus datos son: " + dpi);
              
                btnModAVL.setEnabled(true);
            }
        } else {
            txtAreAVL.setText("El arbol esta vacio");
        }
    }                                            

    
    private void btnEliminarAVLActionPerformed(java.awt.event.ActionEvent evt) {                                               
        
        String bsc = txtAVL.getText();
        long dpi = Long.parseLong(bsc);
        txtAVL.setText("");
        if (!arbolitoAVL.estaVacioElArbol()) {
            if (arbolitoAVL.buscar(dpi, arbolitoAVL.raiz) == null){
                txtAreAVL.setText("Nodo no Encontrado");
            } else {
                arbolitoAVL.setRaiz(arbolitoAVL.eliminarNodo(arbolitoAVL.raiz, dpi));
                txtAreAVL.setText("El Nodo Eliminado");
            }
        } else {
            txtAreAVL.setText("El Arbol esta vacio");
        } 
        
    }                                              

    private void btnModAVLActionPerformed(java.awt.event.ActionEvent evt) {                                          
        this.setVisible(false);
        actAVL.setVisible(true);
        actAVL.setLocationRelativeTo(null);
    }                                         

    private void btnInOrdAVLActionPerformed(java.awt.event.ActionEvent evt) {                                            
        StringBuilder dat = new StringBuilder();
        txtAreAVL.setText("");
        if (arbolitoAVL != null && !arbolitoAVL.estaVacioElArbol()) {
            arbolitoAVL.Enorden(arbolitoAVL.raiz, dat);
        }
        txtAreAVL.setText(dat.toString());
    }                                           

    private void btnPreOrnAVLActionPerformed(java.awt.event.ActionEvent evt) {                                             
        StringBuilder dat = new StringBuilder();
        txtAreAVL.setText("");
        if (arbolitoAVL != null && !arbolitoAVL.estaVacioElArbol()) {
            arbolitoAVL.preorden(arbolitoAVL.raiz, dat);
        }
        txtAreAVL.setText(dat.toString());
    }                                            

    private void btnPostAVLActionPerformed(java.awt.event.ActionEvent evt) {                                           
        StringBuilder dat = new StringBuilder();
        txtAreAVL.setText("");
        if (arbolitoAVL != null && !arbolitoAVL.estaVacioElArbol()) {
            arbolitoAVL.PostOrden(arbolitoAVL.raiz, dat);
        }
        txtAreAVL.setText(dat.toString());
    }                                          

    private void actualizarBBTActionPerformed(java.awt.event.ActionEvent evt) {                                              
        this.setVisible(false);
        act.setVisible(true);
        act.setLocationRelativeTo(null);
    }                                             

    private void btnGrabarArchivoBBTActionPerformed(java.awt.event.ActionEvent evt) {                                                    
        try {
        if (arbolito.EstaVacio()) {
            JOptionPane.showMessageDialog(this, "El árbol binario está vacío.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        } else {
            arbolito.cargarArchivoBBT();
        }
    } catch (Exception e) {
        // Maneja la excepción aquí
        JOptionPane.showMessageDialog(this, "Ocurrió un error al cargar el archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }                                                   

    private void btnCargarArchivoActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        encrip.cargar(arbolito);
    }                                                

    private void btnDesincriptarActionPerformed(java.awt.event.ActionEvent evt) {                                                
      
        try {
            encrip.desencriptarTodos(arbolito.raiz);
            encrip.desencriptarArchivo(encrip.getMiArchivoBBT());
        }catch (IOException ex) {
            Logger.getLogger(MenuPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                               

    private void grabarAVLActionPerformed(java.awt.event.ActionEvent evt) {                                          
        try {
        if (arbolitoAVL.estaVacioElArbol()) {
            JOptionPane.showMessageDialog(this, "El árbol binario está vacío.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        } else {
            arbolitoAVL.cargarArchivoAVL();
        }
    } catch (Exception e) {
        // Maneja la excepción aquí
        JOptionPane.showMessageDialog(this, "Ocurrió un error al cargar el archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }                                         

    private void cargarAVLActionPerformed(java.awt.event.ActionEvent evt) {                                          
        encrip.cargarAVL(arbolitoAVL);
    }                                         

    private void btnIMGAVLActionPerformed(java.awt.event.ActionEvent evt) {                                          
        arbolitoAVL.dibujarGraphviz();
    String path = "arblAVL.png";
    
    // Verifica que la ruta sea correcta
    File file = new File(path);
    if (file.exists()) {
        ImageIcon ic = new ImageIcon(path);
        Image nw = ic.getImage().getScaledInstance(imgLabel.getWidth(), imgLabel.getHeight(), Image.SCALE_SMOOTH); 
        ImageIcon nc = new ImageIcon(nw);
        imgLabel.setIcon(nc);
    } else {
        System.out.println("La imagen no existe en la ruta especificada: " + path);
    }
    }                                         

    private void btnEncripAVLActionPerformed(java.awt.event.ActionEvent evt) {                                             
        try {
            encrip.encriptarAVL(arbolitoAVL.raiz);
            encrip.encriptarArchivo(encrip.getMiArchivoAVL());
        } catch (IOException ex) {
            Logger.getLogger(MenuPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }                                            

    private void btnDesencripAVLActionPerformed(java.awt.event.ActionEvent evt) {                                                
        try {
            encrip.desencriptarAVL(arbolitoAVL.raiz);
            encrip.desencriptarArchivo(encrip.getMiArchivoAVL());
        }catch (IOException ex) {
            Logger.getLogger(MenuPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                               

```


#### Descripcion breve de ambos botones
____
Una breve descripcion de ambos botones en general. 
_____
Boton agregar: se encearga de acceder a la cagita de txtfiel y poder convertir su valor a uno de tipo Long para poder llamar a la instancia del arbolito o arbolitoAVl para llamar al metodo agregar el dpi que se accedio del txtField.
_____
Boton buscar: verifica si el nodo no esta vacio y accede a l valor del txtfield para pasarle como parametro el dpi  o un arbol demas como parametro para que retorne el nodo a buscar y se muestre en el txtArea el valor encontrado

_____
boton eliminar: cumple con la misma funcionalidad verifica si el nodo no esta vacio y si no lo esta se llama al metodo de buscar para que retorne el valor que se desea eliminar  mostrando en el textField si se elimino u no.

____
boton Inorden, preorden y postorden: se encarga de crear un objeto de tipo StringBuilder para ese mismo objeto a los metodos de recorridos y retornar el dato para mostrarlo en el txtArea.
_____

boton encriptar y desencriptar:  se realiza una instacia para acceder a los metodos de encriptar y desincriptar para pasar como parametro un nodo y mandar el archivo a encriptar 

____

boton grabar y cargar: verifica si existe un nodo y en el caso de que si deberia de llamar al metodo de cargarArchivo donde se obtiene un metodo cargar datos al archivo y el de cargar se le pasa un tipo de arbol para poder acceder al arbol y cargar los datos del archivo al arbol
_____
A los botones donde reciben Valores como seleccionar el archivo, eliminar agregar y boton de agregar de moficar se les agrego excepciones y condiciones para comprobar si el boton selecciono un archivo o le dio clic a un boton de salir para que no haya problemas o verifica con una try-catch o los tipos de file, como tambien los datos sin estan vacios de un txtfield.
____

boton de generar imagen Graphviz: la funcionalidad de este boton es estensa pero su funcion es poder acceder a la imagen que se encuentra guardada en el proyecto donde se creo una imagen de tipo png con el proceso de metodos de crear un archivo de pxml y de tipo de doc o mejor conocido como word para poder dibujar el arbol binario en una imagen png y acceder a el para ferificar si exite y adapatar la imagen al label que lo contiene y ser mostrado en pantalla este es el codigo completo de cualquier arbol: 

```
private void btnIMGAVLActionPerformed(java.awt.event.ActionEvent evt) {                                          
        arbolitoAVL.dibujarGraphviz();
    String path = "arblAVL.png";
    
    // Verifica que la ruta sea correcta
    File file = new File(path);
    if (file.exists()) {
        ImageIcon ic = new ImageIcon(path);
        Image nw = ic.getImage().getScaledInstance(imgLabel.getWidth(), imgLabel.getHeight(), Image.SCALE_SMOOTH); 
        ImageIcon nc = new ImageIcon(nw);
        imgLabel.setIcon(nc);
    } else {
        System.out.println("La imagen no existe en la ruta especificada: " + path);
    }
    }        

      public String obtenerCodigoGraphviz() {
    StringBuilder texto = new StringBuilder();
    texto.append("digraph G {\n");
    texto.append("     node [shape = circle, style = filled, fillcolor = \"#EEEEE\", color = \"#EEEEE\", width = 0.5, height = 0.5];\n");
    texto.append("     edge [color = \"#31CEF0\"];\n\n");

    if (raiz != null) {
        texto.append(raiz.textoGraphviz());
    }
    texto.append("}\n");
    return texto.toString();
    }
    
  private void escribirArchivo(String ruta, String contenido){
        FileWriter fichero = null;
        PrintWriter pw = null;
    
        try{
            fichero = new FileWriter(ruta);
            pw = new PrintWriter(fichero);
            pw.write(contenido);
            pw.close();
            fichero.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }finally{
            if(pw!=null){
                pw.close();
            }
        }
    }
    

  public void dibujarGraphviz() {
    try {
        String codigoDot = obtenerCodigoGraphviz();
        System.out.println("Contenido del archivo DOT:");
        System.out.println(codigoDot); // Imprimir el contenido del archivo DOT
        escribirArchivo("archivoAVL.dot", codigoDot);
        ProcessBuilder proceso = new ProcessBuilder("dot", "-Tpng", "-o", "arblAVL.png", "archivoAVL.dot");
        proceso.redirectErrorStream(true);
        Process p = proceso.start();
        
        // Capturar la salida del proceso
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        
        int exitVal = p.waitFor();
        if (exitVal != 0) {
            System.err.println("Error al generar la imagen PNG. Código de salida: " + exitVal);
        } else {
            System.out.println("Imagen PNG generada correctamente.");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    }

    public void setRaiz(NodoAVL raiz) {
        this.raiz = raiz;
    }
    
    



```

___


#### CLASS ACTUALIZACION DEL ARBOL BBT Y AVL (METODOS)
el codigo es el mismo en ambos Jfram solamente que uno esta especificado para diferente arbol. la funcionalidad de la clase y de sus metodos es poder accerder a los txtfield que estan el formulario de los datos que se moficaron al buscar un nodo anteriormente y pasar esos datos como parametro los datos nuevos para insertarlos en el nodo encontrado del arbol bbt o avl, tomando en cuenta que se realizo una instancia para mantener el mismo tipo de arbol y de datos donde se hizo un erencia.

______


```
 private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        MenuPrincipal menu = new MenuPrincipal();

        String depart = txtDepartamento.getText();
        String municipio = txtMunicipio.getText();
        String cantDosis = txtCantDosis.getText();
        String FprimerVac = txtPrimeraVacuna.getText();
        String FsegundaVac = txtSegundaVacuna.getText();
        String FtercerVac = txtTerceraVacuna.getText();
        String lugarVac = txtLugarVac.getText();

        arbolitoAVL.modificar(depart, municipio, cantDosis, FprimerVac, FsegundaVac, FtercerVac, lugarVac);
        
        txtDepartamento.setText("");
        txtMunicipio.setText("");
        txtCantDosis.setText("");
        txtPrimeraVacuna.setText("");
        txtSegundaVacuna.setText("");
        txtTerceraVacuna.setText("");
        txtLugarVac.setText("");
    }                                          
```
---